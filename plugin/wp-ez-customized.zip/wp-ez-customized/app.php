<?php
/**
 * Plugin Name:       wp-ez-customized
 * Plugin URI:        #
 * Description:       wp-ez-customized 放置EZ Web客製內容代碼
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Ben Huang
 * Author URI:        #
 * License:           GPL v2 or later
 * License URI:       #
 * Text Domain:       EZ-WooSetting
 * Domain Path:       /languages
 */

function remove_box () {
    remove_meta_box ('postexcerpt', 'product', 'normal'); // Product data
    remove_meta_box ('woocommerce-product-data', 'product', 'normal'); // Product data
}
add_action ('add_meta_boxes', 'remove_box', 50);

////

add_action('init','tw_disable_create_new_post');
function tw_disable_create_new_post() {

    global $wp_post_types;
    $role = NULL;
    if( is_user_logged_in() ) {
        $user = wp_get_current_user();
        $role = $user->roles[0];  
    }

    if($role!=NULL && $role=="editor") 
    {
        $wp_post_types['page']->cap->create_posts = 'do_not_allow';
        // $wp_post_types['post']->cap->create_posts = 'do_not_allow';
        // $wp_post_types['custom-post-type']->cap->create_posts ='do_not_allow';
    }
}

add_action('admin_head', 'elementor_show_by_role');
function elementor_show_by_role() {

    $role = NULL;
    if( is_user_logged_in() ) {
        $user = wp_get_current_user();
        $role = $user->roles[0];  
    }

    if($role!=NULL && $role=="editor" && strpos($_SERVER['REQUEST_URI'], 'post_type=page'))
    {
        ?>
        <style>
            .subsubsub .all {
                display:none;
            }
            .subsubsub .publish {
                display:none;
            }
            .adminify_duplicate {
                display:none;
            }
            .search-box {
                display:none;
            }
        </style>
        <?php
    }

    if($role!=NULL && $role=="editor" && strpos($_SERVER['REQUEST_URI'], 'action=edit'))
    {
        ?>
        <style>
            #elementor-switch-mode-button {
                display:none;
            }
        </style>
        <?php
    }
}

function hide_personal_options(){
    echo "\n" . '<script type="text/javascript">
    jQuery(document).ready(function($) 
    { 
        $(\'form#your-profile > h3:first\').hide(); 
        $(\'form#your-profile > table:first\').hide(); 
        $(\'form#your-profile\').show(); 
    });
    </script>' . "\n";
}
add_action('admin_head','hide_personal_options');

add_action('elementor/widgets/widgets_registered', function( $widget_manager ){
	$widget_manager->unregister_widget_type('form');
}, 15);

/**
 * Unregister multiple unused widgets.
 *
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function remove_unused_widgets( $widgets_manager ) {

    $role = NULL;
    if( is_user_logged_in() ) {
        $user = wp_get_current_user();
        $role = $user->roles[0];  
    }

    if($role!=NULL && $role=="editor")
    {
        $widgets_to_unregister = [
            // 'common',
            // 'inner-section',
            // 'heading',
            'image',
            'text-editor',
            'video',
            'button',
            'divider',
            'spacer',
            'image-box',
            'google_maps',
            'icon',
            'icon-box',
            'star-rating',
            'image-carousel',
            'image-gallery',
            'icon-list',
            'counter',
            'progress',
            'testimonial',
            'tabs',
            'accordion',
            'toggle',
            'social-icons',
            'alert',
            'audio',
            'shortcode',
            'html',
            'menu-anchor',
            'sidebar',
            'read-more',
            'dynamic-widget',
            'form',
            'jet-listing-dynamic-link',
            'countdown',
            'posts',
            'slides'
        ];
    
        foreach ( $widgets_to_unregister as $widget ) {
            $widgets_manager->unregister( $widget );
        }
    }

}
add_action( 'elementor/widgets/register', 'remove_unused_widgets', 10000);